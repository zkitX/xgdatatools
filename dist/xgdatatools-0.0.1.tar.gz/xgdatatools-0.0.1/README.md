# xgdatatools
Originally created by Michael Petch and was hosted on a website that was not in use anymore, This is only on github for people who want to read this file format which is abandoned by Microsoft.
